// Minimal placeholder for Ethers.js contract hook
export function useContract() {
  return { contract: null, account: null };
}
