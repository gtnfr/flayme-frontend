export default function PnLChart() {
  // Placeholder chart. Replace with real data and a chart lib like Recharts!
  return (
    <div className="w-full h-80 bg-glass rounded-2xl shadow-lg p-6">
      <h2 className="font-poppins text-lg text-orange-200 mb-2">Treasury PnL (Hyperliquid)</h2>
      <div className="flex items-center justify-center h-full text-white opacity-60">
        (PnL chart goes here)
      </div>
    </div>
  );
}
